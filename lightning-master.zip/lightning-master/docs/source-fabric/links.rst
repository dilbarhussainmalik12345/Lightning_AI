.. _PyTorchJob: https://www.kubeflow.org/docs/components/training/pytorch/
.. _Kubeflow: https://www.kubeflow.org
.. _Trainer: https://lightning.ai/docs/pytorch/stable/common/
