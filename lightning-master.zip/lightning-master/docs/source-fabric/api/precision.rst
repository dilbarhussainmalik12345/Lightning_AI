.. include:: ../links.rst

##################################
lightning.fabric.plugins.precision
##################################


Precision
^^^^^^^^^

.. TODO(fabric): include DeepSpeedPrecision

.. currentmodule:: lightning.fabric.plugins.precision

.. autosummary::
    :toctree: ./generated
    :nosignatures:
    :template: classtemplate.rst

    Precision
    DoublePrecision
    MixedPrecision
    TPUPrecision
    TPUBf16Precision
    FSDPPrecision
