.. include:: ../links.rst

########################
lightning.fabric.loggers
########################


Loggers
^^^^^^^

.. currentmodule:: lightning.fabric.loggers

.. autosummary::
    :toctree: ./generated
    :nosignatures:
    :template: classtemplate.rst

    Logger
    CSVLogger
    TensorBoardLogger
