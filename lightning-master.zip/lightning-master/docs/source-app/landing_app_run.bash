# install lightning
pip install lightning

# run the app on the --cloud (--setup installs deps automatically)
lightning run app app.py --setup --cloud
