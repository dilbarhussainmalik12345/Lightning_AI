:orphan:

.. _drive_storage:

#############
Drive Storage
#############

**Audience:** Users who want to put, list, and get files from a shared disk space.

----

.. include:: ../../glossary/storage/drive_content_old.rst
