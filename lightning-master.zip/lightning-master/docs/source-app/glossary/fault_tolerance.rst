:orphan:

###############
Fault tolerance
###############

.. note:: documentation under construction
