*********************************
Take full control of your cluster
*********************************
If you are an experienced user, we can enable you to fully own your cluster
configuration using terraform directly. Please email support@lightning.ai for more information.

----

**************************************
Get help building an optimized cluster
**************************************
For enterprise and academic use-cases, we offer tailored cluster set up in case you don't
have experts in-house. Email support@lightning.ai.
