###################
UI (User Interface)
###################
We use (UI) as short for a **web page** with interactions. Lightning Apps can have multiple
types of UIs.

----

.. include:: index_content.rst
