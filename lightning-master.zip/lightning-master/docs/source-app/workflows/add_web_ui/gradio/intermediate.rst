#######################################
Add a web UI with Gradio (intermediate)
#######################################

.. note:: documentation coming soon.


*************************************
Interact with a component from the UI
*************************************

.. warning:: is there such a thing for this with gradio?


----

*************************************
Interact with the UI from a component
*************************************

.. warning:: is there such a thing for this with gradio?
