###############################
Arrange app tabs (intermediate)
###############################
TODO:

----

***********************************
Render components with a defined UI
***********************************

component directly

----

*************
Render a link
*************

tensorboard link
