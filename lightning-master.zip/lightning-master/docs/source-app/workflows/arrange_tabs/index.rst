################
Arrange App Tabs
################

.. include:: index_content.rst
