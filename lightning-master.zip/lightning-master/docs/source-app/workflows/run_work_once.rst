##########################
Cache LightningWork Runs
##########################

**Audience:** Users who want to know how ``LightningWork`` works.

**Level:** Advanced

**Prereqs**: Level 16+ and read the `Event Loop guide <../glossary/event_loop.html>`_.

----

.. include:: run_work_once_content.rst
