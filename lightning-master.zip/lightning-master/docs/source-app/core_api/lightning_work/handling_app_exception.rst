:orphan:

###############################
Handle Lightning App exceptions
###############################

**Audience:** Users who want to make Lightning Apps more robust to potential issues.

**Level:** Advanced

----

.. include:: handling_app_exception_content.rst
