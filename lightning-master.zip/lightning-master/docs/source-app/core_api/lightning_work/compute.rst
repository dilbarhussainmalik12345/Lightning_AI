:orphan:

.. _cloud_compute:

############################
Customize your Cloud Compute
############################

**Audience:** Users who want to select the hardware to run in the cloud.

**Level:** Intermediate

----

.. include:: compute_content.rst
