:orphan:

##########################################
Communication between Lightning Components
##########################################

**Audience:** Users that want to create interactive applications.

**Level:** Intermediate

**Prerequisite**: Read the `Communication in Lightning Apps article <../../access_app_state.html>`_.

----

.. include:: ../../core_api/lightning_app/communication_content.rst
