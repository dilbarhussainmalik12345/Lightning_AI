# install pip
# install git
# setup an alias for Python: python=python3
# Add the root folder of Lightning to the Environment Variables to PATH
