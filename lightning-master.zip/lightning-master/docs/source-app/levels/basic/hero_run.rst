.. lit_tabs::
   :titles: Lightning Cloud (fully-managed); Your AWS account; Your own hardware
   :code_files: /levels/basic/hello_components/code_run_cloud.bash; /levels/basic/hello_components/code_run_cloud_yours.bash; /levels/basic/hello_components/code_run_local.bash
   :tab_rows: 4
   :highlights: ; 5; 0
   :height: 195px
