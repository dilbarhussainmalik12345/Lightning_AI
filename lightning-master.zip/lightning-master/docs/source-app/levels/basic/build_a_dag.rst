:orphan:

###########################
Example: Deploy a model API
###########################
**Audience:** TODO:

**Prereqs:** You have an app already running locally.

----

****************************
What is the Lightning Cloud?
****************************
The Lightning Cloud is the platform that we've created to interface with the cloud providers. Today
the Lightning Cloud supports AWS.

.. note:: Support for GCP and Azure is coming soon!

To use the Lightning Cloud, you buy credits that are used to pay the cloud providers. If you want to run
on your own AWS credentials, please contact us (support@lightning.ai) so we can get your clusters set up for you.
