# TODO: show how to use terraform to create a cluster called pikachu

# run the cluster
lightning run app app.py --cloud pickachu
