##############################################
Level 18: Share objects between LightningWorks
##############################################
**Audience:** Users moving DataFrames or outputs, between Lightning Works (usually data engineers).

**Prereqs:** Level 16+ and know about the Pandas library and read the `Access app state guide <../../access_app_state.html>`_.

----

.. include:: ../../core_api/lightning_work/payload_content.rst
