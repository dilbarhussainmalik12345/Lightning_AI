##########################
Level 17: Rerun components
##########################
**Audience:** Users who want Work.run() to activate multiple times in an app.

**Prereqs:** Level 16+ and read the `Event Loop guide <../glossary/event_loop.html>`_.

----

.. include:: ../../workflows/run_work_once_content.rst
