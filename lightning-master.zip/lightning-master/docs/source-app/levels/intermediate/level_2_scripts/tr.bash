# custom control for optimized clusters with tools like terraform
# are only supported on the enterprise tier (support@lightning.ai)

# once the cluster is created you can run any app on it
lightning run app app.py --cloud my-custom-optimized-cluster
